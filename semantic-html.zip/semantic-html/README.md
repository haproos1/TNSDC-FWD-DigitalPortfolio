# Semantic.html

A Pen created on CodePen.

Original URL: [https://codepen.io/Haproos-Fathima-Haproos-Fathima/pen/XJmOPow](https://codepen.io/Haproos-Fathima-Haproos-Fathima/pen/XJmOPow).

